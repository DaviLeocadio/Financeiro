(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_4d4b6b04._.css",
  "static/chunks/src_app_b98b9e09._.js"
],
    source: "dynamic"
});

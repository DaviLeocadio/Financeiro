(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_42d0e34a._.css",
  "static/chunks/node_modules_23d4b8cd._.js",
  "static/chunks/[root-of-the-server]__daca5951._.js"
],
    source: "dynamic"
});

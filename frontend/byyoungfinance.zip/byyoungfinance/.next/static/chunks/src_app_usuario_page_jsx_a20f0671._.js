(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_237ea490._.css",
  "static/chunks/node_modules_bootstrap_dist_js_bootstrap_bundle_min_5fde8e51.js",
  "static/chunks/[root-of-the-server]__37918b9d._.js",
  "static/chunks/node_modules_030a4f55._.js"
],
    source: "dynamic"
});

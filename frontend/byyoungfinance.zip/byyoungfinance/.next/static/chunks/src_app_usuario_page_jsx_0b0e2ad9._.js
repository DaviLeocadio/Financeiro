(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_a481ba77._.css",
  "static/chunks/node_modules_bootstrap_dist_js_bootstrap_bundle_min_457451fd.js",
  "static/chunks/[root-of-the-server]__6cfc9ef4._.js",
  "static/chunks/node_modules_030a4f55._.js"
],
    source: "dynamic"
});

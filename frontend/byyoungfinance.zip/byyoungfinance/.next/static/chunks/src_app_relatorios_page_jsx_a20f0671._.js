(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_4111beda._.css",
  "static/chunks/node_modules_23d4b8cd._.js",
  "static/chunks/src_components_40ab5f03._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_1d5d2b4c._.css",
  "static/chunks/node_modules_23d4b8cd._.js",
  "static/chunks/src_8f7cdf2d._.js"
],
    source: "dynamic"
});

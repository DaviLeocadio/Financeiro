(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_64bb7ad8._.css",
  "static/chunks/node_modules_23d4b8cd._.js",
  "static/chunks/src_components_424d3c3e._.js"
],
    source: "dynamic"
});

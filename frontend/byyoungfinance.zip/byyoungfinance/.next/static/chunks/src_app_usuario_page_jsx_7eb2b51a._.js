(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_usuario_usuario_ea2e3f79.css",
  "static/chunks/node_modules_f4095ede._.js",
  "static/chunks/src_components_chart_chart_jsx_f16c5973._.js"
],
    source: "dynamic"
});

(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_581345ff._.css",
  "static/chunks/node_modules_bootstrap_dist_js_bootstrap_bundle_min_77567690.js",
  "static/chunks/[root-of-the-server]__632ee431._.js",
  "static/chunks/node_modules_030a4f55._.js"
],
    source: "dynamic"
});

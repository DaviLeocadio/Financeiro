(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_bootstrap_dist_js_bootstrap_bundle_min_78078831.js",
  "static/chunks/_4139fa8e._.js"
],
    source: "dynamic"
});

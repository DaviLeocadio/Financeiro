(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__e8e30f29._.css",
  "static/chunks/node_modules_e9a10b9b._.js",
  "static/chunks/src_components_40c6eb3f._.js"
],
    source: "dynamic"
});

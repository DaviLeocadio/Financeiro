(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_5430a782._.js",
  "static/chunks/src_components_0fcdcb70._.js",
  "static/chunks/src_1d5d2b4c._.css"
],
    source: "dynamic"
});
